_base_ = 'swin-tiny_16xb64_in1k.py'

_deprecation_ = dict(
    expected='swin-tiny_16xb64_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
