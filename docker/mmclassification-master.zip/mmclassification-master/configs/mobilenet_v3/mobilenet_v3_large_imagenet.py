_base_ = 'mobilenet-v3-large_8xb32_in1k.py'

_deprecation_ = dict(
    expected='mobilenet-v3-large_8xb32_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
