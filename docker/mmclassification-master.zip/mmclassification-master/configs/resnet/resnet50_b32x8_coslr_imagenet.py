_base_ = 'resnet50_8xb32-coslr_in1k.py'

_deprecation_ = dict(
    expected='resnet50_8xb32-coslr_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
