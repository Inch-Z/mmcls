_base_ = '../resnet/resnet50_8xb32-fp16-dynamic_in1k.py'

_deprecation_ = dict(
    expected='../resnet/resnet50_8xb32-fp16-dynamic_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
