_base_ = 'shufflenet-v1-1x_16xb64_in1k.py'

_deprecation_ = dict(
    expected='shufflenet-v1-1x_16xb64_in1k.py',
    reference='https://github.com/open-mmlab/mmclassification/pull/508',
)
